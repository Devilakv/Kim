#!/bin/bash
clear
termux-open-url "https://www.youtube.com/@txgaming6154"
sleep 1
termux-wake-lock
while :
do
echo " \033[01;32m
<-|======================================|->            
\033[01;35m               
            <===[💻|BOT|🤖]===>
\033[01;37m 


Versão:\033[01;32m Grátis \033[01;37m

Criado por: Tx gaming \033[01;36m
https://www.youtube.com/@txgaming6154 \033[01;37m

Instagram: nothing
Discord: _lefted_


SAIR = ( CTRL + C )/Obs: Vai encerrar o bot
\033[01;32m
<-|======================================|-> \033[01;35m  
[CONSOLE BOT💻] \033[01;0m"

    node bot.js

done
